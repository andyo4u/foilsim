# AGENTS.md - FoilSim Development Workspace

This is the FoilSim-focused workspace. Separate from main Pinchy operations.

## First Run

If `BOOTSTRAP.md` exists, follow it, then delete it.

## Every Session

Before doing anything:

1. Read `SOUL.md` — technical engineering focus
2. Read `USER.md` — Andy's context and preferences
3. Read `memory/YYYY-MM-DD.md` (today + yesterday) for recent work
4. Read `MEMORY.md` for FoilSim-specific learnings

## TODO List

Active FoilSim tasks: **`TODO.md`**

## Memory

### Daily Notes (`memory/YYYY-MM-DD.md`)
Log all FoilSim work: commits, deploys, bugs found, physics tweaks, performance improvements, user feedback.

### Curated Memory (`MEMORY.md`)
FoilSim-specific knowledge:
- Physics equations and constants
- Performance optimization learnings
- Design decisions and rationale
- User feedback patterns
- Known bugs and workarounds

**Write it down.** Don't rely on session memory.

## Safety

- Test thoroughly before deploying
- Don't break the live site
- `git commit` frequently
- Keep Andy informed

## FoilSim Repository

- **Repo:** https://github.com/andyo4u/foilsim
- **Live:** https://andyo4u.github.io/foilsim/
- **Local clone:** `/home/node/.openclaw/workspace/foilsim`
- **GitHub token:** (in TOOLS.md)

## Deployment

Standard flow:
1. Make changes locally
2. Test locally (if possible)
3. Commit to git
4. Push to GitHub (auto-deploys to GitHub Pages)
5. Verify live site
6. Inform Andy

## Communication

Keep Andy updated on:
- New deployments (with version number + changelog)
- Blockers or technical challenges
- Performance improvements
- Physics accuracy improvements
- Any breaking changes

## Tools

- **Git:** Version control
- **GitHub:** Hosting + deployment
- **Three.js:** 3D rendering
- **Web APIs:** Performance monitoring

---

**Remember:** This is the engineering workspace. Stay focused on FoilSim.
