# HEARTBEAT.md

## FoilSim Workspace - No Heartbeats

This workspace does not run on heartbeat polls. It's session-based, activated only when Andy messages the foilsim bot directly.

If you receive a heartbeat poll here, reply: HEARTBEAT_OK

---

**Rationale:** FoilSim development is task-driven, not time-driven. No need for periodic checks.
