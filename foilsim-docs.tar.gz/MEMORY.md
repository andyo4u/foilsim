# MEMORY.md - FoilSim Knowledge Base

This is the long-term memory for FoilSim development work.

## Project Status

- **Repo:** https://github.com/andyo4u/foilsim
- **Live:** https://andyo4u.github.io/foilsim/
- **Current Version:** v0.89 (in development, not yet at MVP)
- **Framework:** Three.js r128
- **Last Major Update:** 2026-02-22

## Technical Stack

- **3D Engine:** Three.js r128
- **Physics:** Custom Gerstner wave system, lift/drag calculations
- **Terrain:** Real-world locations (Columbia River Gorge, Maliko Run Maui)
- **Mobile:** Touch controls optimized for Android Chrome
- **Quality:** Adaptive LOD system for performance

## Physics Model

### Wave System
- Gerstner waves with GPU shaders
- 11 render modes available
- Swell controls (add/remove/adjust dynamically)

### Foil Physics
- Lift coefficient calculations
- Drag modeling
- Thrust dynamics
- Stall conditions
- Crash detection
- Battery depletion

## Camera System
- Freelook mode
- Follow camera (3rd person)
- 2-finger touch for freelook on mobile

## Performance

- Adaptive quality/LOD system
- Mobile-first optimization
- GPU-accelerated wave rendering

## Known Issues / TODO

(Will be tracked in TODO.md as they arise)

## User Feedback

- Andy tests primarily on Android Chrome
- Wants realistic physics
- Prefers smooth performance over visual fidelity
- Has experience with Gemini-built version for comparison

## Design Decisions

(Document major decisions here as they're made)

## Deployment

- GitHub Pages via `andyo4u/foilsim` repo
- Auto-deploy on push to main branch
- GitHub token stored in TOOLS.md

---

**Last updated:** 2026-02-28
