# TODO - FoilSim Development

**Current Version:** v0.1.59 (Feb 27, 2026)  
**Live:** https://andyo4u.github.io/foilsim/  
**Analysis:** See `project-analysis.md` for full breakdown

---

## 🔴 High Priority (Critical Path)

### 1. Fix half-screen rendering bug
- **Status:** UNRESOLVED since v0.87 revert
- **Cause:** Runtime `renderer.setPixelRatio()` changes in Three.js r128 cause canvas/buffer mismatch
- **Impact:** Blocks reliable auto-quality system deployment
- **Options:**
  1. Upgrade to Three.js r160+ (major refactor risk)
  2. Fixed pixel ratio per quality level (no runtime changes)
  3. Full canvas recreation on quality change (expensive)
- **Reference:** FOILSIM.md "Known Bugs" section

### 2. Wave energy tuning
- **Problem:** Pumping feels unrewarding (passive regen only 0.06 * dt)
- **Fix needed:** Increase energy gain from slope riding + pumping
- **Impact:** Core gameplay feel
- **Check:** `animate()` energy formula, `slopeForce` contribution

### 3. Define v1.0 MVP criteria
- **Current:** v0.1.59, no formal MVP definition
- **Need:** Clear feature list + quality bar for v1.0 release
- **Candidates:**
  - ✅ Working physics + wave mechanics
  - ✅ 2+ real terrain locations
  - ✅ Mobile touch controls
  - ✅ Tutorial progression
  - ⏳ Jump mechanics?
  - ⏳ Location select screen?
  - ⏳ Strava integration?

---

## 🟡 Medium Priority (Next 1-2 Weeks)

### Location select screen
- **Current:** Dropdown menu in settings
- **Goal:** Proper game loop with visual location picker
- **Options:**
  1. Static screen with location cards (quickest)
  2. Spinning globe with pin markers (ambitious)
  3. Map view with region highlights (middle ground)

### Jump mechanics
- **TODO:** Detect launch conditions (steep wave face + high speed)
- **Impact:** Key differentiator for gameplay depth
- **Reference:** `js/foil.js` TODO line ~600

### Board bounce fix
- **Problem:** `rideH` oscillates rapidly in high wind chop
- **Fix:** Low-pass filtering or aggressive lerp damping
- **Impact:** Visual polish, gameplay feel

### More locations (3-5 new terrains)
- **Current:** Gorge + Maliko only
- **Ideas:** Caribbean, Mediterranean, Australia, Hawaii North Shore
- **Each requires:** Heightmap PNG + satellite JPEG + config entry
- **Variety = content**

---

## 🟢 Low Priority / Future

### Easy/Pro difficulty modes
- Adjust physics params per skill level
- Reference: `js/foil.js` TODO

### Lean-back brake turn
- Apply roll-proportional brake when turning + braking
- Reference: `js/foil.js` TODO

### Power-up re-enable
- Green power-up (pocket highlights activator)
- Reference: `js/main.js` TODO

### Strava integration
- Record GPS trail, upload ride summary
- Distance, time, avg speed, elevation profile
- Reference: `js/terrain.js` TODO

### Visual polish
- [ ] Brighten satellite textures (mountains too dark)
- [ ] Reduce wave tiling (Gerstner repetition)
- [ ] Fix distant water seam (black band at horizon)
- [ ] Foil visual height adjustment (appears too high)

### Multiplayer
- WebRTC or WebSocket real-time sessions
- Multiple riders on same ocean
- Reference: FOILSIM.md "Future Features"

### HELL location
- Ultimate challenge level
- Unlocked after all completions
- Reference: `js/terrain.js` TODO

### Per-location sponsors
- Different branding per terrain
- Example: Slingshot for Columbia River Gorge
- Reference: `index.html` TODO

---

## ✅ Completed

- ✅ 2026-02-27: CPU/GPU wave sync fix (v0.1.59)
- ✅ 2026-02-27: Board float height adjustment (-0.04m rest height)
- ✅ 2026-02-27: Tutorial text clarity improvements
- ✅ 2026-02-28: Cloned repo to foilsim workspace
- ✅ 2026-02-28: Created comprehensive project analysis

---

## 📝 Next Session Priorities

When Andy asks for FoilSim work, prioritize in this order:
1. **Define v1.0 MVP** (strategic clarity)
2. **Wave energy tuning** (gameplay feel)
3. **Location select screen** (UX polish)
4. **Jump mechanics** (feature depth)
5. **More locations** (content variety)

---

**Last updated:** 2026-02-28 by FoilDev 🌊🦀
