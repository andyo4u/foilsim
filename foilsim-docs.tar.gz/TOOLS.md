# TOOLS.md - FoilSim Development Tools

Local configuration and credentials for FoilSim development.

## GitHub

- **Account:** andyo4u
- **Token:** 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
- **FoilSim Repo:** andyo4u/foilsim → https://andyo4u.github.io/foilsim/
- **Local Clone:** /home/node/.openclaw/workspace/foilsim

## Deployment

**GitHub Pages (automatic):**
```bash
cd /home/node/.openclaw/workspace/foilsim
git add .
git commit -m "Description of changes"
git push
# Auto-deploys to https://andyo4u.github.io/foilsim/
```

## Development Environment

- **Linux container:** Headless Debian-based (no GUI/browser)
- **Node.js:** v22.22.0
- **Git:** Available
- **Testing:** Cannot run visual tests (no browser), must deploy to test

## Testing Workflow

1. Make changes to local files
2. Commit to git
3. Push to GitHub
4. Verify at https://andyo4u.github.io/foilsim/
5. Andy tests on Android Chrome
6. Iterate based on feedback

---

**Notes:**
- No local browser testing available (headless environment)
- All visual testing happens via GitHub Pages deployment
- Keep commits small and deployable
