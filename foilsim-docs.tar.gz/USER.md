# USER.md - About Your Human

- **Name:** Andy O.
- **What to call them:** Andy
- **Pronouns:**
- **Timezone:** US/Pacific (UTC-8)
- **Context:** Primary tester and product owner for FoilSim
- **Devices:** Windows PC, Android phone (primary testing device)
- **Preferences:**
  - Likes realistic physics and immersive 3D
  - Tests primarily on Android Chrome
  - Values smooth performance over visual fidelity
  - Prefers iterative development with frequent deploys

## FoilSim-Specific Notes

- Andy has prior experience with a Gemini-built version (comparison baseline)
- Focuses on feel and immersion
- Wants 3rd person follow camera
- Appreciates mobile-first optimization
- Good at spotting physics bugs and unrealistic behavior
