# FoilSim Project Analysis

**Date:** 2026-02-28  
**Version:** v0.1.59  
**Live URL:** https://andyo4u.github.io/foilsim/  
**Repo:** https://github.com/andyo4u/foilsim

---

## 📊 Current State

### Tech Stack
- **Framework:** Three.js r128 (CDN-loaded, no npm)
- **Architecture:** 7 vanilla ES modules (no build tools, no bundler)
- **Hosting:** GitHub Pages (master branch auto-deploy)
- **Development:** Static file server (no CI/CD, no tests, no linter)

### Core Features (Working)
✅ **Wave Physics:** Gerstner waves (3 swell components + wind chop)  
✅ **Real Terrain:** Columbia River Gorge + Maliko Run (heightmap + satellite imagery)  
✅ **Quality System:** 5 presets + Auto FPS-based LOD  
✅ **Mobile Support:** Touch controls (steer/pump pads)  
✅ **Tutorial System:** Progressive skill-building levels  
✅ **11 Render Modes:** Visual debugging + artistic styles  
✅ **Audio:** Web Audio API (wind, water, foil sounds)  

### Recent Fixes (v0.1.59 - Feb 27, 2026)
- **CPU/GPU wave sync** — Fixed 46cm board positioning error from phase offset mismatch
- **Board float height** — Changed rest height from 0 to -0.04m (waves wash over deck naturally)
- **Tutorial text** — Clarified lift mechanics ("maintain lift" vs "keep speed")

---

## 🐛 Known Issues

### Critical
- **Half-screen rendering bug** (unresolved)  
  - Changing `renderer.setPixelRatio()` at runtime causes canvas/buffer mismatch in Three.js r128
  - Triggered by auto-quality system stepping between levels
  - Currently reverted workaround; needs proper fix

### Medium Priority
- **Wave energy display** — Passive regen too low (0.06 * dt), slopeForce not feeding through correctly
- **Board bounce in chop** — `rideH` oscillates rapidly in high wind; needs low-pass filtering
- **Foil visual height** — Board appears too far above water surface (cosmetic)
- **Distant water seam** — Dark band/black seam at far ocean edge
- **Wave tiling** — Gerstner pattern repeats visibly

---

## 🚀 Active TODOs (In-Code)

### Physics & Gameplay
- [ ] Lean-back brake turn — Apply roll-proportional brake when turning + braking
- [ ] Jumping — Detect launch conditions (steep wave face + high speed)
- [ ] Easy/Pro difficulty modes — Adjust physics params per skill level
- [ ] Power-up collisions — Re-enable green power-up (pocket highlights)
- [ ] Adaptive LOD — Dynamically adjust ocean size based on FPS/device

### Visual & Terrain
- [ ] Brighten satellite texture — Mountain features too dark in real terrain modes
- [ ] Reduce wave tiling — Break up Gerstner repetition
- [ ] Distant water blending — Fix dark seam at horizon
- [ ] More locations — Add new terrain configs (suggestions: Caribbean, Mediterranean, Australia)
- [ ] HELL location — Ultimate challenge level (unlocked after all completions)

### Game Loop & UX
- [ ] MVP criteria — Define v1.0 release features
- [ ] Location select screen — Turn terrain dropdown into proper game loop
- [ ] Spinning globe picker — 3D Earth sphere with pin markers for locations
- [ ] Strava integration — Record GPS trail, upload ride summary (distance, time, avg speed, elevation)
- [ ] Per-location sponsors — Different branding per terrain (e.g., Slingshot for Gorge)

---

## 📋 Module Breakdown

| Module | Lines | Purpose | Key Functions |
|--------|-------|---------|---------------|
| `state.js` | ~200 | Shared mutable state | Single source of truth for all modules |
| `main.js` | ~900 | Renderer, animate loop, quality/LOD | `animate()`, `setQuality()`, `rebuildOceanGeometry()` |
| `ocean.js` | ~1200 | Ocean mesh, wave shaders, Gerstner math | `initOcean()`, `getWaveHeight()`, 11 render modes |
| `foil.js` | ~800 | Foil physics, camera, particles | `updateFoilPhysics()`, touch input, spray/wake |
| `terrain.js` | ~700 | Real terrain, cliffs, silhouettes | `rebuildTerrain()`, heightmap + satellite loading |
| `helpers.js` | ~300 | UI utilities, presets | `cacheAllSliders()`, `applyPreset()` |
| `audio.js` | ~400 | Web Audio API sounds | Wind, water, foil audio feedback |
| `tutorial.js` | ~500 | Tutorial progression | Level sequencing, skill challenges |

---

## 🎯 Strategic Priorities

### Short-term (Next 1-2 weeks)
1. **Fix half-screen rendering bug** — Critical for deployment reliability
2. **Wave energy tuning** — Make pumping feel more rewarding (increase passive regen)
3. **Location select screen** — Proper game loop vs dropdown menu

### Medium-term (1-2 months)
1. **Jump mechanics** — Key differentiator for gameplay depth
2. **More locations** — 3-5 new terrains (variety is content)
3. **Strava integration** — Social sharing + competitive element

### Long-term (3-6 months)
1. **Multiplayer** — WebRTC/WebSocket real-time sessions
2. **Leaderboards** — Per-location high scores
3. **v1.0 release** — Defined MVP, polished UX, marketing push

---

## 🔧 Development Workflow

### Making Changes
1. Serve locally: `python -m http.server` or VS Code Live Server
2. Edit code in `index.html` or `js/*.js`
3. Bump version in `index.html` div#version-label
4. Test on desktop + mobile (Chrome DevTools device emulation)
5. Commit with detailed message + co-author tag
6. Push to master → auto-deploys to GitHub Pages

### Commit Template
```
[Brief summary] (vX.X.XX)

[Multi-line explanation of changes — the "why", not just "what"]

[Technical details if needed]

Co-Authored-By: Claude Sonnet 4.6 <noreply@anthropic.com>
```

### Testing Checklist
- [ ] Desktop Chrome/Firefox/Safari
- [ ] Mobile touch controls (iOS Safari, Android Chrome)
- [ ] All 11 render modes load correctly
- [ ] Quality presets + Auto mode
- [ ] Real terrain loading (Gorge + Maliko)
- [ ] Audio playback (wind, water, foil)
- [ ] Tutorial progression

---

## 💡 Architecture Insights

### State Pattern
All shared mutable data lives on `state` object from `state.js`. Every module imports it:
```js
import { state } from './state.js';
```

**Critical gotcha:** `export const` can't be reassigned from outside the declaring module.  
Use `state.property = value` for anything mutable across modules.

### HTML ↔ Module Bridge
`index.html` uses inline `onclick` handlers. `main.js` exports functions to `window.*`:
```js
window.toggleControls = toggleControls;
window.applyPreset = applyPreset;
```

### Init Order (Critical)
```
cacheAllSliders() → initOcean() → initFoil() → initTerrain()
```
`terrain.js` uses `Promise.resolve().then()` to defer access to `state.oceanMat` created in `initOcean()`.

---

## 📈 Future Vision

### Possible Names (Domain Ideas)
- foilbrain.io
- foil-brain.com
- foil-brained.com
- foilrunner.com
- (foilbrain.com is for sale)

### Monetization Ideas
- **Sponsors per location** — Real brands (Slingshot, Lift, Fliteboard) pay for branded locations
- **Pro version** — Unlocks all locations + no ads ($4.99 one-time)
- **Strava Premium integration** — Paid tier for detailed analytics
- **Merch** — T-shirts, stickers with location-specific designs

---

## 🎓 Learning Resources

- **Three.js r128 docs:** https://threejs.org/docs/index.html#manual/en/introduction/Creating-a-scene
- **Gerstner waves:** https://developer.nvidia.com/gpugems/gpugems/part-i-natural-effects/chapter-1-effective-water-simulation-physical-models
- **Ocean shader reference:** https://github.com/jbouny/ocean
- **Foil physics:** https://foilphysics.com (real-world pump mechanics)

---

**Last updated:** 2026-02-28 by FoilDev 🌊🦀
